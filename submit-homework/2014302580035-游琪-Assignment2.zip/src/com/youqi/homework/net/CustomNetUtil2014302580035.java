package com.youqi.homework.net;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

//爬取网页信息
public class CustomNetUtil2014302580035 
{
	public static String GetWebPage(String URL) throws IOException
	{
		String res = "";
		
		HttpClient httpClient = new DefaultHttpClient();
		HttpGet httpGet = new HttpGet(URL);
		HttpResponse httpResponse = httpClient.execute(httpGet);
		
		res = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
        
		return res;
	}
}
