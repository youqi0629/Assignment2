package com.youqi.homework;

import com.youqi.homework.net.CustomNetUtil2014302580035;
import com.youqi.homework.tools.FileTools2014302580035;
import com.youqi.homework.tools.HtmlTools2014302580035;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main2014302580035 
{
	public static final String URL =
			"http://www.thss.tsinghua.edu.cn/publish/soft/3641/2011/20110608151912005129309/20110608151912005129309_.html";

	public static void main(String[] args) 
	{
		new Thread(new Runnable() 
		{
			@Override
			public void run() 
			{
				// TODO Auto-generated method stub
				try 
				{
					String html = CustomNetUtil2014302580035.GetWebPage(URL);
					
					List<String> list = HtmlTools2014302580035.getInfoListByHTML(html);
					
					String temp = "";
					for (String s : list)
					{
						if (s.contains("姓名")){
							temp += s + "\r\n\n";
							continue;
						}
						if (s.contains("职务ְ")){
							temp += s + "\r\n\n";
							continue;
						}
						if (s.contains("地址")){
							temp += s + "\r\n\n";
							continue;
						}
						if (s.contains("清华大学软件学院院长")){
							temp += "简介:" + s + "\r\n\n";
							continue;
						}
						if (s.contains("主要研究方向")){
							temp += s + "\r\n\n";
							continue;
						}

					    String regex_phone = "\\+[0-9]{2}\\-[0-9]{3}\\-[0-9]*" ;
					    String regex_email ="[a-zA-Z]+[a-zA-Z0-9_]*@([a-zA-Z0-9]+\\.)*[a-zA-Z0-9]+";
					    Pattern pt_phone = Pattern.compile(regex_phone);
					    Matcher mt_phone = pt_phone.matcher(s);
					    Pattern pt_email = Pattern.compile(regex_email);
					    Matcher mt_email = pt_email.matcher(s);
					    if(mt_phone.find())
					    {
					    	temp += "电话：" + mt_phone.group() + "\n\n";
					    }
					    if(mt_email.find())
					    {
					    	temp += "邮箱：" + mt_email.group() + "\n\n";
					    }
					}
					FileTools2014302580035.writeString2File(temp);
					System.out.print("爬取完成\n");
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}

		}).start();
	}
}
