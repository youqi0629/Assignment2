package com.youqi.homework.tools;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

//导出网页信息
public class HtmlTools2014302580035 
{
	public static List<String> getInfoListByHTML(String str)
	{
		List<String> list = new ArrayList<String>();
		
		Document doc = Jsoup.parse(str);
		Elements eles = doc.getElementsByTag("p");
		
		for (Element e : eles)
		{
			list.add(e.text());
		}
		
		return list;
	}
}
