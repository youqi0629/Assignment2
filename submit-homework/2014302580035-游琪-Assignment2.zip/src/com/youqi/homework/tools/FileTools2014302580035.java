package com.youqi.homework.tools;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

//信息存入文件
public class FileTools2014302580035
{
	public static void writeString2File(String str) throws IOException
	{
		File file = new File("output.txt");
		if(!file.exists())
            file.createNewFile();
        
        FileOutputStream out = new FileOutputStream(file, false);

    	out.write(str.toString().getBytes());

        out.close();
	}
}
